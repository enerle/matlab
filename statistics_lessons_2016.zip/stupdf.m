function [ft,Ft] = stupdf(t,mu,s,v);
%[ft,Ft] = stupdf(t,mu,s)
%funcion estimadora de la funcion de densidad de probabilidad (pdf en
%ingles) y de la funcion de distribucion de probabilidad  (cdf) de la
%distribucion t-student.
% t : variable aleatoria.
% mu :  promedio de la pdf (valor central).
% s  : desviacion estandar de la distribucion.
% v  : grados de libertad (numero de datos - 1)
%
% ft :  funcion de densidad de probabilidad.
% Ft : funcion de probabilidad acumulativa.
%nota: sum(ft*dt) = 1

%nota: a mayor grados de libertad la distribución t se aproxima a la normal.

dt = mean(diff(t));
n = length(t);
v = n - 1; %aproach to normal distribution

T = (t - mu)./s; 
c = gamma(0.5*(v+1))/(gamma(0.5*v)*sqrt(v*pi)*s); 
ft = c.*(1 + (v^-1).*T.^2) .^ (-0.5*(v+1)); 

ftdt = ft.*dt;
for ii = 1:length(ft);
     Ft(ii) = sum(ftdt(1:ii)); %cdf
end

