clear; close all; clc
%Kolmogorov-Smirnov pdf and cdf

dx = 0.01; x = 0.01:dx:10; j = 1:1000;

for ii = 1:length(x);
    fx(ii) = (8*sum((-1).^(j-1).*(j.^2).*exp(-2.*(j.^2).*(x(ii)^2)))*x(ii));
end
11
fxdx = fx.*dx; 

figure; plot(x,fxdx,'-k','Linewidth',2); grid
axis([0 2 0 .02])
export_fig test.pdf -m1 -gray

%The moments come from xfx and x^2 fx.
for n = 1:4
    M(n) = sum(x.^n .*fxdx);
end

for ii = 1:length(x);
    pks(ii) = 1 - (2*sum((-1).^(j-1).*exp(-2.*(j.^2).*(x(ii)^2))));
end
qks = 1 - pks;

figure; plot(x,pks,'-r','linewidth',2)
hold on; plot(x,qks,'-k','linewidth',2)
h = legend('Pks','Qks = 1-Pks'); 
set(h,'Fontsize',12); grid
axis([0 2 0 1.19])

%Tail probilities 1-L(z)
for ii = 1:length(x);
    P(ii) =  2*sum(exp((-2).*(2.*j - 1).^2 .*x(ii)^2).*(1-exp((2-8.*j).*x(ii)^2)));
end

