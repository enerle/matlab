function [f1,f2,C] = datapdf(data,n)
%[f1,f2,C] = datapdf(data,n)
%Se calcula de funcion de densidad de probabilidad y la funcion de
%distribucion de probabilidad de los datos (data) a partir de la distribucion de 
%frecuencias absolutas (f1) y acumuladas (f2).
% (n) es el numero de intervalos deseados
% (C) es el valor promedio de cada intervalo de clase.
%Para obtener la funcion de distribucion de probabilidad se debe
%hacer (f1*dx) donde dx es el ancho del intervalo. 

ini = min(data); fin = max(data); 
R = fin - ini; A = R/n; IC = ini:A:fin; %intervalos de clase

%frecuencia absoluta
for ii = 1:length(IC)-1;
    index = find(data >= IC(ii) & data < IC(ii)+A);
    f1(ii) = length(data(index)); 
end

 C = ones(n,1).*nan; %aqui se hace el valor promedio de cada intervalo
for jj =  1:length(IC)-1;
    C(jj) = mean(IC(jj:jj+1));
end
C = C'; %para que sea un vector renglon

%frecuencia acumulada
for ii = 1:length(f1);
    f2(ii) = sum(f1(1:ii));
end

    f1 = f1./(length(data).*A); % Funcion de densidad de probabilidad
    f2 = f2./max(f2); % Funcion de probabilidad acumalada
