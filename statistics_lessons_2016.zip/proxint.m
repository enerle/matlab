function [pro1,pro2,des1,des2,N] = proxint(data1,data2,n)
%[pro1,pro2,des1,des2,N] = proxint(data,paso);
%Calcula el promedio (pro) y la desviacion estandar (des)
%analogo al promedio por intervalos de un diagrama de dispersion entre 
%los conjuntos de datos (data1 y data2) para (n) intervalos de clase.
%Ademas se incluye el vector N que corresponde al numero de
%datos utilizados para obtener los estadisticos por intervalos de clase.

ini = floor(min(data1)); fin = ceil(max(data1)); 
R = fin - ini; A = R/n; IC = ini:A:fin; %intervalos de clase

for ii = 1:length(IC)-1;
    index = find(data1 >= IC(ii) & data1 < IC(ii)+A); %sensado por IC
    pro1(ii) = mean(data1(index)); des1(ii) = std(data1(index));
    pro2(ii) = mean(data2(index)); des2(ii) = std(data2(index));
    N(ii) = length(data1(index));
    
end
end