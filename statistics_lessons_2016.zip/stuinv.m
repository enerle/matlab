function tp = stuinv(p,v); 
% tp = stuinv(alpha,v); 
%Valor critico tp (percentil) asociado al limite de confianza, para diferentes 
%valores de alpha (= 1-p) con p = 95,99,99.99..., y para v grados de libertad.
%Para la distribucion t-student. El valor critico se obtiene de la inversa de la 
%funcion de la funcion de distribucion de probabilidad acumulativa. la inversa de
%la funcion se obtiene por expansiones de Taylor. El polinimio utilizado se tomo 
%de  Abramowitz y Stegun, "Handbook of Mathematical Functions" pp 949. 

x = norminv(p);

g1 = (x^3 + x)/4;
g2 = (5*x^5 + 16*x^3 + 3*x)/96;
g3 = (3*x^7 + 19*x^5 + 17*x^3 - 15*x)/384;
g4 = (79*x^9 + 776*x^7 + 1482*x^5 - 1920*x^3 - 945*x)/92160;

tp = x + g1/v + g2/v^2 + g3/v^3 + g4/v^4; %valor aproximado por expansiones de Taylor

    

