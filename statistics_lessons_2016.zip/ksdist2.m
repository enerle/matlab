clear; close all; clc
%Kolmogorov-Smirnov pdf and cdf

N =100; 
D = 0.1;
x =  D*(0.12 + sqrt(N) + 0.11/sqrt(N));
j = 1:1000;

Q = 2*sum((-1).^(j-1).*exp(-2.*(j.^2).*x^2))

