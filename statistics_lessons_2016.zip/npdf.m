function [fx,Fx,M] = npdf(x,m,s)
%[fx,Fx,M] = npdf(x,m,s)
%funcion estimadora de la funcion de densidad de probabilidad (pdf en
%ingles) y de la funcion de distribucion de probabilidad  (cdf). Ademas se
%incluye la estimacion de los momentos estadisticos de la distribucion normal.
% x : variable aleatoria.
% m :  promedio de la pdf (valor central).
% s  : desviacion estandar de la distribucion.
%
% fx :  funcion de densidad de probabilidad.
% Fx : funcion de probabilidad acumulativa.
% M :  vector con los principales momentos estadisticos centrados
%       M(1):media,  M(2):varianza, M(3):sesgo y M(4):curtosis
%nota: sum(fx*dx) = 1

dx = mean(diff(x));
z = -((x-m).^2)./(2*s^2);
fx = (1/(s*sqrt(2*pi))) .* exp(z); %densidad

for n = 1:4;
%     E = (x.^n).*fx; M(n) = trapz(x,E); %integral
     M(n) = sum((x.^n).*fx*dx);
end

M(3) = M(3)/s^3;
M(4) = M(4)/s^4;

fxdx = fx.*dx;
for ii = 1:length(fx);
    Fx(ii) = sum(fxdx(1:ii)); %cdf
end
% fx = fx.*dx; %probabilidad


