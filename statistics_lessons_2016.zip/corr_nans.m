function [C,nupar] = corr_nans(x,y)
% [C,nupar] = corr_nans(x,y)
% Funcion para correlacionar dos series de datos (x,y)
% con presencia de nans. Las series debe de medir lo mismo. 
% Las salidas son la correlacion lineal (C) y el numero de pares (nupar)
% con los que se hace la correlacion.

index = isnan(x); x(index) = []; y(index) = [];
index = isnan(y); x(index) = []; y(index) = [];
nupar = length(x);

[~,xp] = metrica_error(x); [~,yp] = metrica_error(y);
dxy = sum((x-xp).*(y-yp));
dxdy = sum((x-xp).^2) * sum((y-yp).^2);
C = dxy/sqrt(dxdy);
end