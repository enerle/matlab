function [B,Y,E,r2] =regresion_log(x,y,n);
%[B,Y,E,r2] = regresion_log(x,y,n)
%igual que el programa de regresion pero para un 
%ajuste logaritmico de la forma Y = a + b*log(x) + c*log(x)^2 + ...

x = x(:); y = y(:);

X = ones(length(y),2);
for ii = 1:n;
    X(:,ii+1) = log(x).^ii; 
end

% Minimos cuadrados.
M = inv(X'*X); B = M*X'*y; Y = X*B;
E = y - X*B;

my = mean(y);
scr = sum((Y-my).^2); %suma de los cuadrados de la regresión
sct = sum((y-my).^2); %suma de los cuadrados del total
r2 = scr/sct; %coeficiente de determinacion o varianza explicada por el ajuste.
r = sqrt(r2); %coeficiente de correlacion.
