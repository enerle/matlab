%26 y 27 de septiembre 2017.
%Ren� N.

clc; clear; close all;

x = 0:16; y = [15 34 50 75 80 83 90 97 72 55 42 32 25 19 15 12 10];

figure(1); plot(x,y,'ok','markersize',8,'markerface',[.6 .6 .6]); grid;
xlabel('{\sl Variable independiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')
ylabel('{\sl Variable dependiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')

%Interpolacion
figure(1); plot(x,y,'ok','markersize',8,'markerface',[.6 .6 .6]); grid;
xlabel('{\sl Variable independiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')
ylabel('{\sl Variable dependiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')

for ii = 1:length(x);
    [B,Y,errB,E,ve] = ajuste_mincuad(x,y,ii,0);
    hold on; plot(x,Y,'-k','Linewidth',2);
    pause
end

%Extrapolacion
x = 0:7; y = [15 34 50 75 80 83 90 97];
figure(2); plot(x,y,'ok','markersize',8,'markerface',[.6 .6 .6]); grid;
xlabel('{\sl Variable independiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')
ylabel('{\sl Variable dependiente}','Interpreter','Latex','fontsize',16,'fontweight','bold','FontName','Times')

X = 0:20; %domino extrapolado
B = ajuste_mincuad(x,y,3,0); hold on; plot(X,B(1) + B(2).*X + B(3).*X.^2+ B(4).*X.^3,'-','Linewidth',2,'Color',[0 0 0]); %orden 3
B = ajuste_mincuad(x,y,2,0); hold on; plot(X,B(1) + B(2).*X + B(3).*X.^2,'-','Linewidth',2,'Color',[.4 .4 .4]); %orden 2
B = ajuste_mincuad(x,y,1,0); hold on; plot(X,B(1) + B(2).*X,'-','Linewidth',2,'Color',[.7 .7 .7]); %orden 1

print -r300 -djpeg99 inter_extra.jpg

