function zp = ninv(p); 
%zp = ninv(p,mu,s); 
%Valor critico tp (percentil) asociado al limite de confianza, para diferentes 
%valores de alpha (= 1-p) con p = 95,99,99.99..., y para media (mu) y
%desviacion estandar (s) para la distribucion Z (normal). 
%El valor critico se obtiene de la inversa de la 
%funcion de la funcion de distribucion de probabilidad acumulativa.
%La inversa de la funcion se obtiene por expansiones de Taylor. El polinimio utilizado se tomo 
%de  Abramowitz y Stegun, "Handbook of Mathematical Functions" pp 933. 

% a0 = 2.30753;
% a1 = 0.27061;
% b1 = 0.99229;
% b2 = 0.04481;
% t = sqrt(log(1/p^2)); 
% 
% zp = t - (a0 + a1*t)/(1 + b1*t + b2*t^2) + 3e-3;

c0 = 2.515517;
c1 = 0.802853; 
c2 = 0.010328;
d1 = 1.432788;
d2 = 1.432788;
d3 = 0.001308;

t = sqrt(log(1/p^2)); 
zp = t - (c0 + c1*t + c2*t^2)/(1 + d1*t + d2*t^2 + d3*t^3) + 4.5e-4;
