function [rg,pro,med,vrz,dest,sonan] = metrica_error(x)
% [pro,med,mo,vrz,dest] = metrica_error(x)
% Funcion que estima los principales estadisticos centrales y de dispresion
% de una serie de datos (x) con presencia de NaNs. Se obtiene el media o
% promedio (pro), la mediana (med), moda (mo), varianza (vrz), desviacion
% estandar (dest) y el numero de nans en la serie (sonan).

index = isnan(x); sonan = sum(index); x(index) = [];
rg = max(x) - min(x); 
pro = sum(x)/length(x); % Media.

if length(x)/2  == floor(length(x)/2);
    med = (length(x)/2 + (length(x)/2 + 1))/2;
else
    med = (length(x) + 1)/2;
end

vrz = sum((x - pro).^2)/length(x); % Varianza.
dest = sqrt(vrz); % Desviacion estandar.
end